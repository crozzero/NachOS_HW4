#include "syscall.h"

int
main ()
{
    while(1){
    }
    Exit(1);
}