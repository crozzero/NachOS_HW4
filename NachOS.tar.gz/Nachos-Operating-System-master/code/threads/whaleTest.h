#ifndef WHALETEST_H
#define WHALETEST_H

#include "whale.h"

class WhaleTest{

  public:
	WhaleTest(){}
	~WhaleTest(){}
	void start(int testnum);

  private:
    

};



#endif//MAILBOXTEST_H