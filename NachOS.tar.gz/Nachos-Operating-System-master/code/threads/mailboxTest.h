#ifndef MAILBOXTEST_H
#define MAILBOXTEST_H

#include "mailbox.h"

class MailboxTest {
public:
	MailboxTest(){
		
	}
	~MailboxTest(){
	//	delete mailbox;
	}
	void start(int testnum);
private:
	

};
#endif//MAILBOXTEST_H